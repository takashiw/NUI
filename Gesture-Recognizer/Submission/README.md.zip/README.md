Takashi Wickes
twickes32
java -jar pdollar.jar <arguments after>
    Example:
    java -jar pdollar.jar -t arrowhead.txt -t five_point_star.txt -t exclamation_point.txt sample_eventfile.txt -r sample_eventfile.txt
Developed on Mac OS, Executable on Any
